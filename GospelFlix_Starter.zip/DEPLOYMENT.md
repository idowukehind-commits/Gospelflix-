# GospelFlix deployment guide (Android + Chrome)

## A. Publish the website with Cloudflare Pages
1. On your Android phone, open Chrome and create/sign in to a Cloudflare account.
2. Create a GitHub account if you do not have one.
3. Create a new GitHub repository named `gospelflix`.
4. Upload the contents of this project folder to the repository (upload files, not the ZIP itself).
5. In Cloudflare, open Workers & Pages → Create → Pages → Connect to Git.
6. Choose the `gospelflix` repository.
7. Framework preset: None. Build command: leave blank. Build output directory: `/` (or `.` if required by the interface).
8. Deploy. Cloudflare will provide a public `pages.dev` address.

## B. Create the database
1. Visit supabase.com and create a project.
2. Open SQL Editor → New query.
3. Copy all of `supabase/schema.sql` into the editor and run it.
4. In Authentication, create your own user account.
5. In Table Editor → profiles, find your profile and change role from `viewer` to `admin`.
6. Keep your database password and service-role key private. Never put a service-role key in website JavaScript.

## C. What is not live yet
This first version is a front-end prototype. The database schema is prepared, but the website is not connected to it yet. Movie playback, secure admin uploads, user login, and ads need a next development phase. Use a streaming provider that supports adaptive playback and access control; do not put large video files directly in the website repository.

## D. Before public launch
- Add a privacy policy, terms, content ratings and contact details.
- Obtain rights/permission for every film, poster, music track and trailer.
- Add moderation and secure administrator authentication.
- Test on Android, slow mobile networks and different screen sizes.
- Integrate an ad provider only after reviewing its age, privacy and content requirements.
