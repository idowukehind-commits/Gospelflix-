# GospelFlix starter
A mobile-first front-end prototype for an African Christian movie catalogue.

## Preview
Open `index.html` in a browser. For deployment, upload this folder to a static host such as Cloudflare Pages.

## Included
- Responsive home page, GospelFlix styling
- Movie catalogue, search and category filters
- Movie detail dialogs
- PWA manifest
- Initial Supabase SQL schema with row-level security

## Important
This is a front-end starter, not yet a production streaming service. The catalogue contains fictional placeholder titles and no playable films. It has no live authentication, admin dashboard, uploads, ad network, or video hosting yet. Only publish films you own or are licensed to distribute. Do not paste Supabase service-role keys into browser code.

## Supabase setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Create an admin account through Supabase Auth.
4. Promote that account manually in the SQL editor:
   `update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';`
5. Keep admin privileges server-side; never expose service-role keys.

## Deployment
See `DEPLOYMENT.md`. The site can be hosted free on Cloudflare Pages for an initial prototype. A real streaming platform also needs a video host/CDN, playback access controls, ad integration, privacy policy, terms and security testing.
